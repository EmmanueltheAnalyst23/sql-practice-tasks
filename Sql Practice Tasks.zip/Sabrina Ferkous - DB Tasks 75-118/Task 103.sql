-- Task 103


SELECT 
    p.Name AS ProductName,
    pc.Name AS ProductCategoryName,
    soh.SalesOrderID AS OrderNumber
FROM 
    SalesLT.Product p
INNER JOIN 
    SalesLT.SalesOrderDetail sod ON p.ProductID = sod.ProductID
INNER JOIN 
    SalesLT.SalesOrderHeader soh ON sod.SalesOrderID = soh.SalesOrderID
INNER JOIN 
    SalesLT.ProductCategory pc ON p.ProductCategoryID = pc.ProductCategoryID
ORDER BY 
    p.Name;
