-- Task 98 Query: Retrieve sales order data

SELECT 
    SalesOrderHeader.OrderDate,
    SalesOrderHeader.SalesOrderNumber,
    Product.Name AS ProductName,
    SalesOrderDetail.OrderQty AS Quantity,
    SalesOrderDetail.UnitPrice AS Price,
    SalesOrderDetail.LineTotal
FROM SalesLT.SalesOrderHeader
INNER JOIN SalesLT.SalesOrderDetail
ON SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID
INNER JOIN SalesLT.Product
ON SalesOrderDetail.ProductID = Product.ProductID
ORDER BY SalesOrderHeader.OrderDate, Product.Name;
