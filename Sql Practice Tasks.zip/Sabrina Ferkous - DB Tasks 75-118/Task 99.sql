-- Task 99 Query: Use an OUTER JOIN to include all customers

SELECT 
    Customer.FirstName, 
    Customer.LastName,
    SalesOrderHeader.SalesOrderNumber
FROM SalesLT.Customer AS Customer
LEFT JOIN SalesLT.SalesOrderHeader AS SalesOrderHeader
ON Customer.CustomerID = SalesOrderHeader.CustomerID
ORDER BY Customer.LastName, Customer.FirstName;
