-- Task 80: Returning last name trimmed, concatenated with first name, and in uppercase

SELECT UPPER(LTRIM(RTRIM(LastName))) + ', ' + UPPER(FirstName) AS FullName
FROM Person.Person;
