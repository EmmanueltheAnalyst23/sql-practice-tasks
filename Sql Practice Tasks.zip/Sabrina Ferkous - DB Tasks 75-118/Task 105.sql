-- Task 105

SELECT 
    c.FirstName + ' ' + c.LastName AS CustomerName,
    a.AddressLine1 + ', ' + a.City + ', ' + a.StateProvince + ', ' + a.PostalCode AS FullAddress,
    soh.SalesOrderID,
    soh.TotalDue
FROM 
    SalesLT.Customer c
INNER JOIN 
    SalesLT.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID
INNER JOIN 
    SalesLT.Address a ON soh.ShipToAddressID = a.AddressID;
