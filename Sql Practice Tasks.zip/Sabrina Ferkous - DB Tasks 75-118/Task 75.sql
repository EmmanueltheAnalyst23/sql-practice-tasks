-- Task 75: Selecting all columns from the "Sales.SalesOrderHeader" table

SELECT * 
FROM Sales.SalesOrderHeader;
