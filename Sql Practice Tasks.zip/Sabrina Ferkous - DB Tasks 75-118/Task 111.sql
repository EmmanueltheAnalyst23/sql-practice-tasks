-- Task 111

SELECT 
    JobTitle, 
    COUNT(*) AS NumberOfEmployees
FROM 
    HumanResources.Employee
GROUP BY 
    JobTitle
HAVING 
    COUNT(*) > 5;
