-- Task 104

SELECT 
    ParentCategory.Name AS ParentCategory,
    SubCategory.Name AS SubCategory
FROM 
    SalesLT.ProductCategory AS ParentCategory
LEFT JOIN 
    SalesLT.ProductCategory AS SubCategory ON ParentCategory.ProductCategoryID = SubCategory.ParentProductCategoryID
ORDER BY 
    ParentCategory.Name, SubCategory.Name;
