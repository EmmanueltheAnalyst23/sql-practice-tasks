-- Task 86: Selecting "Name" and "Color" from "Production.Product" for products with an empty "Weight"

SELECT Name, Color
FROM Production.Product
WHERE Weight IS NULL;
