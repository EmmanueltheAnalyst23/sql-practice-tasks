-- Task 84: Selecting "Name" and "Color" from "Production.Product" for products that are not 'Black'

SELECT Name, Color
FROM Production.Product
WHERE Color != 'Black';
