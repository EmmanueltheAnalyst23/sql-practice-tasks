-- Task 100 Query: Modify the above query to exclude customers with orders

SELECT 
    Customer.FirstName, 
    Customer.LastName
FROM SalesLT.Customer AS Customer
LEFT JOIN SalesLT.SalesOrderHeader AS SalesOrderHeader
ON Customer.CustomerID = SalesOrderHeader.CustomerID
WHERE SalesOrderHeader.CustomerID IS NULL;
