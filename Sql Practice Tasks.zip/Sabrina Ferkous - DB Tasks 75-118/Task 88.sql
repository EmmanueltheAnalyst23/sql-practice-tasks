-- Task 88: Selecting "SalesOrderID" and "OrderDate" from "Sales.SalesOrderHeader" for orders placed before 2014

SELECT SalesOrderID, OrderDate
FROM Sales.SalesOrderHeader
WHERE YEAR(OrderDate) < 2014;
