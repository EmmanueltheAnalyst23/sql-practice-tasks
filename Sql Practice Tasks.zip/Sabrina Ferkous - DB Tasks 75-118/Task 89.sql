-- Task 89: Selecting "Name" and "ListPrice" from "Production.Product" for red-colored products with a ListPrice greater than 500

SELECT Name, ListPrice
FROM Production.Product
WHERE Color = 'Red' AND ListPrice > 500;
