-- Task 81: Selecting "FirstName" and "LastName" for Salespersons with EmailPromotion

SELECT FirstName, LastName
FROM Person.Person
WHERE PersonType = 'SP' AND EmailPromotion = 1;