-- Task 77: Selecting unique values of the "Color" column from the "Production.Product" table

SELECT DISTINCT Color 
FROM Production.Product;
