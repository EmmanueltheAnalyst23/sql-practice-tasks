-- Task 113

SELECT 
    p.Name AS ProductName,
    COUNT(sod.SalesOrderID) AS NumberOfSales,
    FORMAT(SUM(sod.LineTotal), 'C', 'en-US') AS TotalValue
FROM 
    SalesLT.Product p
INNER JOIN 
    SalesLT.SalesOrderDetail sod ON p.ProductID = sod.ProductID
GROUP BY 
    p.Name
ORDER BY 
    SUM(sod.LineTotal) DESC;
