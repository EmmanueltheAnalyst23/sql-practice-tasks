-- Task 91: Selecting product names and subcategories using INNER JOIN

SELECT p.Name AS ProductName, s.Name AS SubcategoryName
FROM Production.Product p
INNER JOIN Production.ProductSubcategory s ON p.ProductSubcategoryID = s.ProductSubcategoryID;
