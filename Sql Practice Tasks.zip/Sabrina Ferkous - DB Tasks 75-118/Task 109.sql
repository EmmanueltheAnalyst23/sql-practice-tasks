-- Task 109

SELECT 
    JobTitle, 
    COUNT(*) AS NumberOfEmployees
FROM 
    HumanResources.Employee
GROUP BY 
    JobTitle;
