-- Task 85: Selecting "FirstName" and "LastName" for individuals who are 'Store contacts' or 'Vendor contact' and have an EmailPromotion


SELECT FirstName, LastName
FROM Person.Person
WHERE (PersonType = 'SC' OR PersonType = 'VC') AND EmailPromotion = 2;
