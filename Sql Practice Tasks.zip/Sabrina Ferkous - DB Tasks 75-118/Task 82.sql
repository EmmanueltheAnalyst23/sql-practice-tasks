-- Task 82: Selecting "Name" and "ListPrice" from "Production.Product" for products with a ListPrice between 500 and 1000

SELECT Name, ListPrice
FROM Production.Product
WHERE ListPrice BETWEEN 500 AND 1000;
