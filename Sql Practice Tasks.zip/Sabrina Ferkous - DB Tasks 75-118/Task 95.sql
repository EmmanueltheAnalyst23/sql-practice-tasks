-- Product and Category Relationship


SELECT Product.Name AS ProductName, ProductCategory.Name AS CategoryName
FROM SalesLT.Product
INNER JOIN SalesLT.ProductCategory
ON Product.ProductCategoryID = ProductCategory.ProductCategoryID;
