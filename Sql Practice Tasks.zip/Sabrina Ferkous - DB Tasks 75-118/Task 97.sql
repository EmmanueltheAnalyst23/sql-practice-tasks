-- Task 96-97: Product and Parent Category


SELECT 
    Child.Name AS CategoryName,
    Parent.Name AS ParentCategoryName
FROM SalesLT.ProductCategory AS Child
LEFT JOIN SalesLT.ProductCategory AS Parent
ON Child.ParentProductCategoryID = Parent.ProductCategoryID;

