-- Task 110

SELECT 
    CustomerID, 
    SUM(TotalDue) AS TotalSales
FROM 
    Sales.SalesOrderHeader
GROUP BY 
    CustomerID;
