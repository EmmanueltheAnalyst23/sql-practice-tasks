-- Task 106

SELECT 
    p.Name AS ProductName,
    pc.Name AS CategoryName,
    ppc.Name AS ParentCategory
FROM 
    SalesLT.Product p
LEFT JOIN 
    SalesLT.ProductCategory pc ON p.ProductCategoryID = pc.ProductCategoryID
LEFT JOIN 
    SalesLT.ProductCategory ppc ON pc.ParentProductCategoryID = ppc.ProductCategoryID
ORDER BY 
    p.Name, pc.Name, ppc.Name;
