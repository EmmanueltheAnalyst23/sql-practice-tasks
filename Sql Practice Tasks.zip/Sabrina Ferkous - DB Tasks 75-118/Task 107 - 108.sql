-- Task 107

USE AdventureWorks2022;



-- Task 108
SELECT 
    Name, 
    ListPrice
FROM 
    Production.Product
WHERE 
    ListPrice > 500;
