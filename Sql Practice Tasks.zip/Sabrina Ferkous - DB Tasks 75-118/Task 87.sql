-- Task 87: Selecting "FirstName" and "LastName" from "Person.Person" for individuals whose last names start with 'S'

SELECT FirstName, LastName
FROM Person.Person
WHERE LastName LIKE 'S%';
