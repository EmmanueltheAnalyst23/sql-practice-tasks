-- Task 83: Selecting "FirstName" and "LastName" from "Person.Person" where last names are in a list of values

SELECT FirstName, LastName
FROM Person.Person
WHERE LastName IN ('Smith', 'Johnson', 'Brown');
