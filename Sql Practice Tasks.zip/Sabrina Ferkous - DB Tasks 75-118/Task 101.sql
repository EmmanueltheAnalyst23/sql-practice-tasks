-- Task 101: Retrieve product descriptions

SELECT 
    Product.Name AS ProductName,
    SalesOrderDetail.SalesOrderID AS OrderNumber
FROM SalesLT.Product
INNER JOIN SalesLT.SalesOrderDetail
ON Product.ProductID = SalesOrderDetail.ProductID
INNER JOIN SalesLT.SalesOrderHeader
ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID;
