-- Task 102: Include only ordered products

SELECT 
    Product.Name AS ProductName,
    SalesOrderDetail.SalesOrderID AS OrderNumber
FROM SalesLT.Product
INNER JOIN SalesLT.SalesOrderDetail
ON Product.ProductID = SalesOrderDetail.ProductID
WHERE SalesOrderDetail.SalesOrderID IS NOT NULL;
