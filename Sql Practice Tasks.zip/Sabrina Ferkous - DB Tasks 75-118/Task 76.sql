-- Task 76: Selecting specific columns (ProductID, Name, and ListPrice) from the "Production.Product" table

SELECT ProductID, Name, ListPrice 
FROM Production.Product;
