-- Task 90: Selecting "FirstName" and "LastName" for individuals who are employees with more than 40 vacation hours

SELECT FirstName, LastName
FROM Person.Person
WHERE BusinessEntityID IN (SELECT BusinessEntityID FROM HumanResources.Employee WHERE VacationHours > 40);
