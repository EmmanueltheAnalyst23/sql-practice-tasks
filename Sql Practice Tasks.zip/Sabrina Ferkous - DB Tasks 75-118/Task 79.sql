-- Task 79: Selecting "Name" and "ListPrice" from "Production.Product" and sort by ListPrice in descending order

SELECT Name, ListPrice 
FROM Production.Product
ORDER BY ListPrice DESC;
