-- Task 78: Select FirstName and LastName from "Person.Person" table for individuals with EmailPromotion

SELECT FirstName, LastName 
FROM Person.Person
WHERE EmailPromotion = 1;  